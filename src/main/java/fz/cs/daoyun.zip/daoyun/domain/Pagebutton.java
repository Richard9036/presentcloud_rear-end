package fz.cs.daoyun.domain;

public class Pagebutton {
    private Integer pagebuttonId;

    private Integer buttonId;

    private Integer menuId;

    public Integer getPagebuttonId() {
        return pagebuttonId;
    }

    public void setPagebuttonId(Integer pagebuttonId) {
        this.pagebuttonId = pagebuttonId;
    }

    public Integer getButtonId() {
        return buttonId;
    }

    public void setButtonId(Integer buttonId) {
        this.buttonId = buttonId;
    }

    public Integer getMenuId() {
        return menuId;
    }

    public void setMenuId(Integer menuId) {
        this.menuId = menuId;
    }
}
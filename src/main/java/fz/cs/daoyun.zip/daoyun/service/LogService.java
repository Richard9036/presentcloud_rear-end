package fz.cs.daoyun.service;

import fz.cs.daoyun.utils.po.Log;
import fz.cs.daoyun.utils.service.IService;

public interface LogService extends IService<Log> {

}

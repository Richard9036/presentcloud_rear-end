/**
 * PO（Persistent Object）：持久化对象，它跟持久层（通常是关系型数据库）的数据结构形成一一对应的映射关系.
 */
package fz.cs.daoyun.utils.po;

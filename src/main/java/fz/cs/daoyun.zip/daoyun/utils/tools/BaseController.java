package fz.cs.daoyun.utils.tools;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author cjbi
 */
public class BaseController {

    protected Logger logger = LoggerFactory.getLogger(this.getClass());


    public BaseController() {

    }

}

/**
 * DTO（Data Transfer Object） ：数据传输对象， Service 或 Manager 向外传输的对象。
 */
package fz.cs.daoyun.utils.dto;
